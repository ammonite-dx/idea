export const ARMOR_TYPES: string[] = [
    "防具",
    "防具(補助)",
]