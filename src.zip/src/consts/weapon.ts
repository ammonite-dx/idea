export const WEAPON_TYPES: string[] = [
    "白兵",
    "射撃",
    "白兵/射撃",
]

export const WEAPON_SKILLS: string[] = [
    "〈白兵〉",
    "〈射撃〉",
    "〈RC〉",
    "〈交渉〉",
    "〈知識:機械工学〉",
]