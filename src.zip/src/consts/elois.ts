export const ELOIS_TYPES = [
    "一般",
    "シナリオクラフト専用",
];

export const ELOIS_SUPPLEMENTS = [
    "上級",
    "PE",
    "LM",
];

export const ELOIS_TIMINGS = [
    "メジャーアクション",
    "オートアクション",
    "セットアッププロセス",
    "イニシアチブプロセス",
    "常時",
]

export const ELOIS_SKILLS = [
    "—",
    "〈意志〉",
]

export const ELOIS_DFCLTIES = [
    "自動成功",
    "対決"
]

export const ELOIS_TARGETS = [
    "自身",
    "単体",
    "範囲(選択)",
    "シーン",
    "シーン(選択)",
    "効果参照",
]

export const ELOIS_RNGS = [
    "至近",
    "視界",
    "効果参照",
]

export const ELOIS_URGES = [
    "—",
    "解放",
    "吸血",
    "飢餓",
    "殺戮",
    "破壊",
    "加虐",
    "嫌悪",
    "闘争",
    "妄想",
    "自傷",
    "恐怖",
    "憎悪",
];