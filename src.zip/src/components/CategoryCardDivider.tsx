export default function CategoryCardDivider () {
    return <hr className="border-neutral-200 dark:border-neutral-600"/>
}