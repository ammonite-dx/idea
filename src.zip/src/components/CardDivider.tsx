export default function CardDivider () {
    return (
        <div className="py-1 lg:py-2"><hr className="border-neutral-900 dark:border-neutral-200"/></div>
    )
}